//Lost a large amount of code due to a file error that occurred during uploading to another machine due to this  the file had to be reverted back to an earlier save which caused the loss
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using GameboardGUI;

namespace O_Neillo_Game
{
    public enum Player
    {
        One,
        Two
    }

    public class GameState
    {
        public int[,] GameBoard { get; set; }
        public Player CurrentPlayer { get; set; }
        public string Player1Name { get; set; }
        public string Player2Name { get; set; }
    }

    public partial class Main : Form
    {
        private const string gameDataFilePath = "game_data.json";
        private const int maxSavedGameStates = 5;


        const int NUM_OF_BOARD_ROWS = 8;
        const int NUM_OF_BOARD_COL = 8;

        private Panel gameplayPanel;
        private Panel gameInfoPanel;

        private Label player1Tokens;
        private Label player2Tokens;
        private Label nextPlayer;

        private PictureBox player1Colour;
        private PictureBox player2Colour;

        private TextBox player1Name;
        private TextBox player2Name;

        GameboardImageArray _gameboardGui;
        int[,] gameBoardData;
        string tileImagesDirPath = Directory.GetCurrentDirectory() + @"\images\";

        private const int EMPTY_SQUARE = 10;
        private const int WHITE_TOKEN = 1;
        private const int BLACK_TOKEN = 0;

        private Player currentPlayer = Player.One;

        public Main()
        {
            InitializeComponent();

            InitializeGUI();

            Point top = new Point(100, 100);
            Point bottom = new Point(100, 100);

            gameBoardData = MakeBoardArray();

            try
            {
                _gameboardGui = new GameboardImageArray(this, gameBoardData, top, bottom, 0, tileImagesDirPath);
                _gameboardGui.TileClicked += new GameboardImageArray.TileClickedEventDelegate(GameTileClicked);
                _gameboardGui.UpdateBoardGui(gameBoardData);
            }
            catch (Exception ex)
            {
                DialogResult result = MessageBox.Show(ex.ToString(), "Game board size problem", MessageBoxButtons.OK);
                this.Close();
            }
        }

        private int[,] MakeBoardArray()
        {
            int[,] boardArray = new int[NUM_OF_BOARD_ROWS, NUM_OF_BOARD_COL];

            for (int row = 0; row < NUM_OF_BOARD_ROWS; row++)
            {
                for (int col = 0; col < NUM_OF_BOARD_COL; col++)
                {
                    boardArray[row, col] = EMPTY_SQUARE;
                }
            }

            boardArray[3, 3] = WHITE_TOKEN;
            boardArray[4, 4] = WHITE_TOKEN;
            boardArray[3, 4] = BLACK_TOKEN;
            boardArray[4, 3] = BLACK_TOKEN;

            return boardArray;
        }

        private void GameTileClicked(object sender, EventArgs e)
        {
            int selectionRow = _gameboardGui.GetCurrentRowIndex(sender);
            int selectionCol = _gameboardGui.GetCurrentColumnIndex(sender);

            if (IsMoveValid(selectionRow, selectionCol))
            {
                PerformMove(selectionRow, selectionCol);
            }
            else
            {
                MessageBox.Show("Invalid move. Please try again.");
            }
        }

        private bool IsMoveValid(int row, int col)
        {
            return gameBoardData[row, col] == EMPTY_SQUARE && IsValidMove(row, col, GetPlayerToken());
        }

        private void PerformMove(int row, int col)
        {
            int currentPlayerToken = GetPlayerToken();

            gameBoardData[row, col] = currentPlayerToken;
            FlipOpponentTokens(row, col, currentPlayerToken);
            _gameboardGui.UpdateBoardGui(gameBoardData);

            SwitchPlayerTurn();
            UpdateGameInfo();

            if (!IsAnyValidMoveLeft())
            {
                MessageBox.Show("No legal moves left. Game over!");
                // Optionally, provide an option to reset the game.
            }
        }

        private int GetPlayerToken()
        {
            return currentPlayer == Player.One ? WHITE_TOKEN : BLACK_TOKEN;
        }


        private bool IsValidMove(int row, int col, int currentPlayerToken)
        {
            if (gameBoardData[row, col] != EMPTY_SQUARE)
                return false; // The selected tile is not empty

            // Check in all eight directions for opponent's tokens
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0)
                        continue; // Skip the current position

                    int x = row + i;
                    int y = col + j;

                    if (IsValidPosition(x, y) && gameBoardData[x, y] != currentPlayerToken && gameBoardData[x, y] != EMPTY_SQUARE)
                    {
                        // Opponent's token found in this direction; check if there's a line of opponent's tokens
                        while (IsValidPosition(x, y) && gameBoardData[x, y] != EMPTY_SQUARE)
                        {
                            if (gameBoardData[x, y] == currentPlayerToken)
                                return true; // Valid move

                            x += i;
                            y += j;
                        }
                    }
                }
            }

            return false; // No valid move found
        }

        private bool IsValidPosition(int row, int col)
        {
            return row >= 0 && row < NUM_OF_BOARD_ROWS && col >= 0 && col < NUM_OF_BOARD_COL;
        }

        private void FlipOpponentTokens(int row, int col, int currentPlayerToken)
        {
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0)
                        continue; // Skip the current position

                    int x = row + i;
                    int y = col + j;

                    if (IsValidPosition(x, y) && gameBoardData[x, y] != currentPlayerToken && gameBoardData[x, y] != EMPTY_SQUARE)
                    {
                        // Opponent's token found in this direction; flip tokens until reaching own token
                        while (IsValidPosition(x, y) && gameBoardData[x, y] != currentPlayerToken && gameBoardData[x, y] != EMPTY_SQUARE)
                        {
                            gameBoardData[x, y] = currentPlayerToken; // Flip opponent's token
                            x += i;
                            y += j;
                        }
                    }
                }
            }
        }

        private bool IsAnyValidMoveLeft()
        {
            for (int row = 0; row < NUM_OF_BOARD_ROWS; row++)
            {
                for (int col = 0; col < NUM_OF_BOARD_COL; col++)
                {
                    if (IsMoveValid(row, col))
                    {
                        return true; // Found a valid move
                    }
                }
            }

            return false; // No valid moves left
        }





        private void SwitchPlayerTurn()
        {
            currentPlayer = (currentPlayer == Player.One) ? Player.Two : Player.One;
            nextPlayer.Text = "Next Player: " + (currentPlayer == Player.One ? player1Name.Text : player2Name.Text);
        }

        private void UpdateGameInfo()
        {
            int player1Count = CountTokens(WHITE_TOKEN);
            int player2Count = CountTokens(BLACK_TOKEN);

            player1Tokens.Text = "Player 1 Tokens: " + player1Count;
            player2Tokens.Text = "Player 2 Tokens: " + player2Count;

            nextPlayer.Text = "Next Player: " + (currentPlayer == Player.One ? player1Name.Text : player2Name.Text);

            if (player1Count + player2Count == NUM_OF_BOARD_ROWS * NUM_OF_BOARD_COL)
            {
                MessageBox.Show("Game Over!");
                this.Close();
            }
        }

        private int CountTokens(int token)
        {
            int count = 0;

            for (int row = 0; row < NUM_OF_BOARD_ROWS; row++)
            {
                for (int col = 0; col < NUM_OF_BOARD_COL; col++)
                {
                    if (gameBoardData[row, col] == token)
                    {
                        count++;
                    }
                }
            }

            return count;
        }


        private void InitializeGUI()
        {
            // Sets the title of the application window
            this.Text = "O'Neillo Game";

            // Sets the application icon
            //this.Icon = new System.Drawing.Icon("Icon.PNG");

            // Set the fixed size of the application window
            this.ClientSize = new System.Drawing.Size(900, 600); // Adjust the width and height as needed

            // Prevent resizing of the window
            this.MaximizeBox = false;

            // Set the form border style to FixedSingle
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Remove the sizing grip in the bottom-right corner
            this.SizeGripStyle = SizeGripStyle.Hide;


            // Initialize the menu bar
            InitializeMenuBar();

            // Initialize the game information panel
            InitializeGameInfoPanel();
        }

        private void InitializeMenuBar()
        {
            // Creates a MenuStrip
            MenuStrip menuStrip = new MenuStrip();

            // Creates the "Game" menu item
            ToolStripMenuItem gameMenu = new ToolStripMenuItem("Game");

            // Create the "Settings" menu item
            ToolStripMenuItem settingsMenu = new ToolStripMenuItem("Settings");

            // Creates the "Help" menu item
            ToolStripMenuItem helpMenu = new ToolStripMenuItem("Help");

            // Adds menu items to the MenuStrip
            menuStrip.Items.Add(gameMenu);
            menuStrip.Items.Add(settingsMenu);
            menuStrip.Items.Add(helpMenu);

            // Creates the "New Game" menu item
            ToolStripMenuItem newGameMenuItem = new ToolStripMenuItem("New Game");


            // Adds the "New Game" menu item to the "Game" menu
            gameMenu.DropDownItems.Add(newGameMenuItem);
            newGameMenuItem.Click += NewGameMenuItem_Click;

            // Sets the MenuStrip for the form
            this.Controls.Add(menuStrip);

            // Creates the "Exit" menu item
            ToolStripMenuItem exitMenuItem = new ToolStripMenuItem("Exit");
            exitMenuItem.Click += new EventHandler(ExitMenuItem_Click);

            // Adds the "Exit" menu item to the "Game" menu
            gameMenu.DropDownItems.Add(exitMenuItem);

        }
        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            // Closes the application
            this.Close();
        }
        private void NewGameMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to start a new game?", "New Game Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Resets the game state and starts a new game
                gameBoardData = MakeBoardArray();
                _gameboardGui.UpdateBoardGui(gameBoardData);
                currentPlayer = Player.One; // Sets the starting player
                UpdateGameInfo();
            }
        }

        private void InitializeGameInfoPanel()
        {
            // Creates a Panel to represent the game information area
            gameInfoPanel = new Panel();
            gameInfoPanel.Size = new System.Drawing.Size(this.ClientSize.Width, 100); // Set the size of the game information panel
            gameInfoPanel.Location = new System.Drawing.Point(0, this.ClientSize.Height - gameInfoPanel.Height); // Align to the bottom
            gameInfoPanel.BackColor = System.Drawing.Color.LightGray; // Set the background color

            // Adds the game information panel to the form
            this.Controls.Add(gameInfoPanel);

            // Creates labels to display game information
            player1Tokens = new Label();
            player1Tokens.Text = "Player 1 Tokens: "; // Set initial text
            player1Tokens.Location = new System.Drawing.Point(10, 10);
            player1Tokens.AutoSize = false;
            player1Tokens.Size = new System.Drawing.Size(150, 20);
            gameInfoPanel.Controls.Add(player1Tokens);

            player1Colour = new PictureBox();
            player1Colour.Size = new System.Drawing.Size(50, 50); // Sets the size of the image
            player1Colour.Location = new System.Drawing.Point(140, 10);
            player1Colour.Image = Image.FromFile("white.png"); // Loads the Player 1 colour image
            gameInfoPanel.Controls.Add(player1Colour);

            player1Name = new TextBox();
            player1Name.Text = "Player 1"; // Set initial text
            player1Name.Location = new System.Drawing.Point(250, 30);
            player1Name.Size = new System.Drawing.Size(100, 20); // Sets the size of the TextBox
            gameInfoPanel.Controls.Add(player1Name);

            player2Tokens = new Label();
            player2Tokens.Text = "Player 2 Tokens: "; // Sets initial text
            player2Tokens.Location = new System.Drawing.Point(400, 10);
            player2Tokens.AutoSize = false;
            player1Tokens.Size = new System.Drawing.Size(150, 20);
            gameInfoPanel.Controls.Add(player2Tokens);

            player2Colour = new PictureBox();
            player2Colour.Size = new System.Drawing.Size(50, 50); // Sets the size of the image
            player2Colour.Location = new System.Drawing.Point(510, 10);
            player2Colour.Image = Image.FromFile("black.png"); // Loads the Player 2 colour image
            gameInfoPanel.Controls.Add(player2Colour);

            player2Name = new TextBox();
            player2Name.Text = "Player 2"; // Set initial text
            player2Name.Location = new System.Drawing.Point(640, 30);
            player2Name.Size = new System.Drawing.Size(100, 20); // Sets the size of the TextBox
            gameInfoPanel.Controls.Add(player2Name);

            nextPlayer = new Label();
            nextPlayer.Text = "Next Player: "; // Sets initial text
            nextPlayer.Location = new System.Drawing.Point(800, 10);
            gameInfoPanel.Controls.Add(nextPlayer);
        }
    }
}



