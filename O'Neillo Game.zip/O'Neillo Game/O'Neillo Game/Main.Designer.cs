﻿namespace O_Neillo_Game
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // Other class-level declarations...

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gameplayPanel = new System.Windows.Forms.Panel();
            this.gameInfoPanel = new System.Windows.Forms.Panel();
            this.player1Tokens = new System.Windows.Forms.Label();
            this.player2Tokens = new System.Windows.Forms.Label();
            this.nextPlayer = new System.Windows.Forms.Label();
            this.player1Colour = new System.Windows.Forms.PictureBox();
            this.player2Colour = new System.Windows.Forms.PictureBox();
            this.player1Name = new System.Windows.Forms.TextBox();
            this.player2Name = new System.Windows.Forms.TextBox();

            // Other control declarations...

            this.SuspendLayout();

            // Set up properties and events for controls...

            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 600);
            this.Controls.Add(this.gameplayPanel);
            this.Controls.Add(this.gameInfoPanel);



            this.Name = "Main";
            this.Text = "O'Neillo Game";
            this.ResumeLayout(false);



            #endregion
        }
    }
}